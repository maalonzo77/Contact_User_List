var Firebase = require("firebase");
var Actions = require("../actions/Actions.js");

module.exports = {
	keepContact: function(contact){
		this.firebaseRef = new Firebase("address-book-app-8ad80.firebaseio.com/contacts");
		this.firebaseRef.push({contact: contact});
		console.log(this.firebaseRef)
	},
	getContacts: function(){
		this.firebaseRef = new Firebase("address-book-app-8ad80.firebaseio.com/contacts");
		this.firebaseRef.once("value", function(snapshot){
			var contacts = [];
			snapshot.forEach(function(snap){
				var contact = {
					id: snap.key(),
					name: snap.val().contact.name,
					last: snap.val().contact.lastname,
					add: snap.val().contact.address

				};
				contacts.push(contact);
				Actions.receiveContacts(contacts);
			});


		});
	},
	removeContact: function(id){
		this.firebaseRef = new Firebase("address-book-app-8ad80.firebaseio.com/contacts/"+id);
		this.firebaseRef.remove();
	},
	updateContact: function(contact){
		var id = contact.id
		var updatedContact = {
			name: contact.name,
			lastname: contact.lastname
,
			address: contact.address

		}
		this.firebaseRef = new Firebase("address-book-app-8ad80.firebaseio.com/contacts/"+id+"/contact");
		this.firebaseRef.update(updatedContact);
	}

};