var React = require("react");
var Actions = require("../actions/Actions.js")

var EditContact = React.createClass({

	render: function(){
		return(
			<div className="well">
				<h3>Edit Contact</h3>
				<form onSubmit={this.onSubmit}>
					<div className="form-group" >
						<input type="text" ref="name" className="form-control" value={this.props.contactToEdit.name} onChange={this.handleChange.bind(this, "name")}/>
					</div>
					<div className="form-group">
						<input type="text" ref="lastname" className="form-control" value={this.props.contactToEdit.lastname} onChange={this.handleChange.bind(this, "lastname")}/>
					</div>
					<div className="form-group">
						<input type="text" ref="address" className="form-control" value={this.props.contactToEdit.address} onChange={this.handleChange.bind(this, "address")}/>
					</div>
					<button type="submit" className="btn btn-default">Submit</button>
				</form>
			</div>
		)
	},
	handleChange: function(field,e){
		var selected = this.props.contactToEdit
		selected[field] = e.target.value
		this.setState({
			selected: selected
		})
	},

	onSubmit:function(e){
		e.preventDefault()

		var contact = {
			id: this.props.contactToEdit.id,
			name: this.refs.name.value.trim(),
			address: this.refs.address.value.trim(),
			lastname: this.refs.lastname.value.trim()
		}
		Actions.updateContact(contact)
	}


})

module.exports = EditContact;