var React = require("react");
var Actions = require("../actions/Actions.js")

var AddContacts = React.createClass({
	
	render: function(){
		return(
			<div className="well">
				<h3>Contact Info</h3>
				<form onSubmit={this.onSubmit}>
					<div className="form-group" >
						<input type="text" ref="name" className="form-control" placeholder="Enter Contact Name"/>
					</div>
					<div className="form-group">
						<input type="text" ref="lastname" className="form-control" placeholder="Enter Contact Last Name"/>
					</div>
					<div className="form-group">
						<input type="text" ref="address" className="form-control" placeholder="Enter Contact Address"/>
					</div>
					<button type="submit" className="btn btn-default">Submit</button>
				</form>
			</div>
		)
	},

	onSubmit:function(e){
		e.preventDefault()

		var contact = {
			name: this.refs.name.value.trim(),
			address: this.refs.address.value.trim(),
			last: this.refs.lastname.value.trim()
		}

		Actions.keepContact(contact);
	}

})

module.exports = AddContacts;